from django.contrib import admin
from .models import RatingReview

admin.site.register(RatingReview)