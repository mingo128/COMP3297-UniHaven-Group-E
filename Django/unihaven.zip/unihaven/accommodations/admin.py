from django.contrib import admin
from .models import Accommodation

admin.site.register(Accommodation)